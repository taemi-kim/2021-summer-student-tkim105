#ifndef __STRING_FUNCTIONS_H__
#define __STRING_FUNCTIONS_H__

int concat(const char word1[], const char word2[], char result[], int result_capacity);

#endif
